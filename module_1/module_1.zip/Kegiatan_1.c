#include <stdio.h>
	
int main(){
	
	int kal,pan,ork;

	//Follow For More_^
	printf("Masukan Nilai Kalkulus	: ");
	scanf("%d", &kal);
	printf("Masukan Nilai Pancasila	: ");
	scanf("%d", &pan);
	printf("Masukan Nilai Orkom	: ");
	scanf("%d", &ork);
	printf("\n\n");
	printf("Nilai Kalkulus Kamu: %d\nNilai Pancasila Kamu: %d\nNilai Orkom Kamu: %d\n",kal, pan, ork);
	
	return 0;
}
