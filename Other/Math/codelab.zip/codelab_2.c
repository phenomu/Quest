

#include <stdio.h>

int main() {
	int i, j;
	//matrix ke 1
	int m1[2][2] = {
		{1, 2},
		{3, 4}
	};
	//matrix ke 2
	int m2[2][2] = {
		{5, 6},
		{7, 8}
	};
	int hasil[2][2];

	//lakukan perulangan ketika i lebih kecil dari 2
	for (i = 0; i < 2; i++) {
		//lakukan perulangan ketika j lebih kecil dari 2
		for (j = 0; j < 2; j++) {
			/*	seperti
			hasil[0][0] = m1[0][0] + m2[0][0] hasilnya (6)
			hasil[0][1] = m1[0][1] + m2[0][1] hasilnya (8) dan seterusnya..
			*/
			hasil[i][j] = m1[i][j] + m2[i][j];
		}
	}

	printf("Hasil perjumlahan matriks: \n");
	for (i = 0; i < 2; i++) {
		for (j = 0; j < 2; j++) {
			if(j==0){
				/* disini saya menggunakan kondisi agar outputnya lebih rapi seperti
					{6, 8}
					{10, 12}
				*/
				printf("{ %d,", hasil[i][j]);
			}else{
				printf(" %d }", hasil[i][j]);
			}
		}
		printf("\n");
	}

	return 0;
}