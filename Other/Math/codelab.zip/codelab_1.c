#include <stdio.h>
#include <string.h>

int main() {
	int i;
	//buat array 'agents' dengan ukuran 5x10
	char agents[5][10] = {
		"neon",
		"gekko",
		"omen",
		"sage",
		"jett"
	};
	//karena di C tidak ada built-in function seperti len() atau count() :v
	//jadi saya pakai cara dibawah ini untuk menghitung size array
	int totalAgent = sizeof(agents) / sizeof(agents[0]);
	printf("Daftar Agen:\n");
	//lakukan perulangan ketika i lebih kecil dari total agents
	for (i = 1; i <= totalAgent; i++) {
		printf("Agent ke-%d: %s\n", i, agents[i-1]);
	}
	//ubah agent ke 4 menjadi kage, disini ditulis agents[3] karena index array dimulai dari 0
	strcpy(agents[3], "kage");

	printf("\nDaftar Agen setelah perubahan:\n");
	for (i = 1; i <= totalAgent; i++) {
		printf("Agent ke-%d: %s\n", i, agents[i-1]);
	}

	return 0;
}